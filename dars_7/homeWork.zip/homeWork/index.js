const inputText = document.querySelector('#inputText')
const button = document.querySelector('#button')
button.addEventListener('click', () => {
	if(inputText.value.trim() != ''){
        let li = document.createElement('li')
        li.innerHTML = inputText.value
        list.append(li)
        let span = document.createElement('span')
        let btn = document.createElement('button')
        btn.style.backgroundColor = 'red'
        btn.style.color = 'white'
        btn.style.borderColor = 'green'
        btn.innerHTML = 'X'
        li.append(span,btn)
        btn.addEventListener('click', () => li.remove())
    }
    inputText.value = ""

})
