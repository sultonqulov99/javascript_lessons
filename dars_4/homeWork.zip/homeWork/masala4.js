function numbers(arr){
    return [...new Set(arr)]
}
console.log(numbers([]));