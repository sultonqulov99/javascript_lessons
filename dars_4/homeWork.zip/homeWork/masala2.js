function www(arr){
    let a = []
    for (let i = 0; i < arr.length; i++) {
        if(!arr[i]){
            a.push(0)
            
        }
    }
    for (let i = 0; i < arr.length; i++) {
        if(arr[i]){
            a.push(arr[i])
        }
    }
    return a
}
console.log(www([0,13,0,54,0,0]));