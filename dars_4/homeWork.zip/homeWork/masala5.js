function makeNegative(num){
    if(num <= 0) return num
    else return num = num - num * 2
}
console.log(makeNegative(-0.12));