const tbody = document.querySelector('#trId')
const etable = document.querySelector('.e-table')

function renderUsers(){
    for (const user of users) {
        const [tr,td1,div,input,label,td2,td3,span,td4,i1,td5,divbutton,button1,button2,i] = 
        elaments('tr','td','div','input','label','td','td','span','td','i','td','div','button','button','i')
        td1.classList.add('align-middle')
        div.classList.add('custom-control', 'custom-control-inline', 'custom-checkbox', 'custom-control-nameless', 'm-0', 'align-top')
        input.className = "custom-control-input"
        label.className = 'custom-control-label'
        input.setAttribute('type', 'checkbox')
        input.setAttribute('id', user.userId)
        label.setAttribute('for', user.userId)
        td2.className = "text-nowrap align-middle"
        td3.className = "text-nowrap align-middle"
        td4.className = "text-center align-middle"
        i1.className = "fa fa-fw text-secondary cursor-pointer fa-toggle-off"
        td5.className = "text-center align-middle"
        divbutton.className = "btn-group align-top"
        button1.className = "btn btn-sm btn-outline-secondary badge"
        button2.className = "btn btn-sm btn-outline-secondary badge"
        i.className = "fa fa-trash"
        div.append(input,label)
        td2.textContent = user.username
        button1.textContent = 'Edit'
        span.textContent = user.contact
        td1.append(div)
        td3.append(span)
        td4.append(i1)
        button2.append(i)
        divbutton.append(button1,button2)
        td5.append(divbutton)
        tr.append(td1,td2,td3,td4,td5)
        tbody.append(tr)
        div.addEventListener('click',() => {
            if(!user.checked){
                user.checked = true
                window.localStorage.setItem('users',JSON.stringify(users))
                
            }
        })
        i1.addEventListener('click', ()=>{
            if(!user.status){
                i1.className = "fa fa-fw text-secondary cursor-pointer fa-toggle-on"
                user.status = true
            }
            else{
                i1.className = "fa fa-fw text-secondary cursor-pointer fa-toggle-off"
                user.status = false
            }
        })
    }
        const [div,ul,li1,li2,li3,li4,li5,a1,a2,a3,a4,a5] = elaments('div','ul','li','li','li','li','li','a','a','a','a','a')
        div.className = 'd-flex justify-content-center'
        ul.className = 'pagination mt-3 mb-0'
        li1.className = 'disabled page-item'
        li2.className = 'active page-item'
        li3.className = 'page-item'
        li4.className = 'page-item'
        li5.className = 'page-item'
        a1.className = 'page-link'
        a2.className = 'page-link'
        a3.className = 'page-link'
        a4.className = 'page-link'
        a5.className = 'page-link'
        a1.textContent = '‹'
        a2.textContent = '1'
        a3.textContent = '2'
        a4.textContent = '›'
        a5.textContent = '»'
        li1.append(a1)
        li2.append(a2)
        li3.append(a3)
        li4.append(a4)
        li5.append(a5)
        ul.append(li1,li2,li3,li4,li5)
        div.append(ul)
        etable.append(div)
        li2.addEventListener('click',()=>{
            li2.className = 'active page-item'
            li3.className = 'page-item'
        })
        li3.addEventListener('click',()=>{
            li3.className = 'active page-item'
            li2.className = 'page-item'
        })
}
window.localStorage.setItem('users',JSON.stringify(users))


renderUsers()