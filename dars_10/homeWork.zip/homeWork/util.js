function elaments(...array){
    return array.map(el => document.createElement(el))
}