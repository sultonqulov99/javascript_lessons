let users = window.localStorage.getItem('users')

users = JSON.parse(users) || [
    {userId: 1, username: 'Abdulla',contact: "998975662017",checked: false,status:false},
    {userId: 2, username: 'Qodir',contact: "998975656017",checked: false,status:false},
    {userId: 3, username: 'Zoir',contact: "998972312017",checked: false,status:false},
    {userId: 4, username: 'Adham',contact: "998975662017",checked: false,status:false},
    {userId: 5, username: 'Odilbek',contact: "998987662017",checked: false,status:false},
    {userId: 6, username: 'Abdulla',contact: "998975662321",checked: false,status:false},
    {userId: 7, username: 'Temur',contact: "998975667896",checked: false,status:false},
    {userId: 8, username: 'Qodir',contact: "998975661254",checked: false,status:false},
    {userId: 9, username: 'Sobir',contact: "998975623145",checked: false,status:false},
    {userId: 10, username: 'Odilbek',contact: "998975662017",checked: false,status:false}
]