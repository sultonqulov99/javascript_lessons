const users = [
    {
        nameProblem: 'Two Sum',
        description: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target. You may assume that each input would have exactly one solution, and you may not use the same element twice',
        example: ["Input: nums = [2,7,11,15], target = 9","Output: [0,1]","Explanation: Because nums[0] + nums[1] == 9, we return [0, 1]"],
        status: false
    },
    {
        nameProblem: 'Single Number',
        description: 'Given a non-empty array of integers nums, every element appears twice except for one. Find that single one.You must implement a solution with a linear runtime complexity and use only constant extra space.',
        example: ["Input: nums = [2,2,1]","Output: 1"],
        status: false
    },
    {
        nameProblem: 'Contains Duplicate',
        description: 'Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct.',
        example: ["Input: nums = [1,2,3,1]","Output: true"],
        status: false
    },
]