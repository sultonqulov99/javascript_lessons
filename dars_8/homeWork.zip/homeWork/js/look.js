
//const main = document.querySelector('.main')
const mainHeaders= document.querySelector('.main-headers')
const customer = document.querySelector('.customer-item')
const customerList = document.querySelector('.customers-list')
const button = document.querySelector('button')
let clientId = 0
button.addEventListener('click', ()=>{
    if(usernameInput.value.length < 15 && usernameInput.value.trim() != "" &&
        telephoneInput.value.length == 13 && telephoneInput.value[0] == '+' && 
        telephoneInput.value[1] == 9 && telephoneInput.value[2] == 9 &&
        telephoneInput.value[3] == 8){
            let li = document.createElement('li')
            let span = document.createElement('span')
            let a = document.createElement('a')
            li.classList.add('customer-item')
            span.classList.add('customer-name')
            a.classList.add('customer-phone')
            span.append(usernameInput.value)
            a.append(telephoneInput.value)
            li.append(span)
            li.append(a)
            customerList.append(li)
            clientId++
    }
    else{
        alert('Malumot xato')
    }

})
const li = document.querySelector('.customer-item')
customerList.addEventListener('click', ()=>{
    mainHeaders.innerHTML = null
    let cutomerIdWrapper = document.createElement('div')
    let span1 = document.createElement('span')
    let span2 = document.createElement('span')
    let h1 = document.createElement('h1')
    cutomerIdWrapper.className = 'cutomer-id-wrapper'
    span2.id = 'clientId'
    h1.id = 'userHeader'
    h1.className = 'customer-name'
    span1.textContent = 'client id:'
    span2.textContent = clientId
    h1.textContent = usernameInput.value

    cutomerIdWrapper.append(span1,span2)
    mainHeaders.append(cutomerIdWrapper,h1)

})
const mainOrders = document.querySelector('.main-orders')
const ordersList = document.querySelector('.orders-list')
const mainFooter = document.querySelector('.main-footer')

let form = document.createElement('form')
let select = document.createElement('select')
let optionC = document.createElement('option')
let optionF = document.createElement('option')
let optionB = document.createElement('option')
let optionCH = document.createElement('option')
let optionCO = document.createElement('option')
let optionS = document.createElement('option')
let input = document.createElement('input')
let btn = document.createElement('button')
let imgIcon = document.createElement('img')
btn.type="button"
imgIcon.src = "https://img.icons8.com/plasticine/100/000000/plus-math.png"
btn.append(imgIcon)
input.id = 'foodsCount'
input.type = 'number'
input.placeholder = 'count'
form.id = 'foodsForm'
select.id = 'foodsSelect'
optionC.textContent = 'cola'
optionF.textContent = 'fanta'
optionB.textContent = 'burger_cheese'
optionCH.textContent = 'chicken_wings'
optionCO.textContent = 'combo'
optionS.textContent = 'spinner'

    select.append(optionC,optionF,optionB,optionCH,optionCO,optionS)
    form.append(select)  
    form.append(input,btn)
    mainFooter.append(form)


btn.addEventListener('click', ()=>{
    let li = document.createElement('li')
    let div = document.createElement('div')
    let span1 = document.createElement('span')
    let span2 = document.createElement('span')
    let img = document.createElement('img')
    
    li.className = 'order-item'
    span1.className = 'order-name'
    span2.className = 'order-count'
    span1.textContent = foodsSelect.value
    span2.textContent = foodsCount.value
    img.src = `./img/${foodsSelect.value}.jpeg`

    div.append(span1,span2)
    li.append(img,div)
    ordersList.append(li)
    mainOrders.append(ordersList)
})
