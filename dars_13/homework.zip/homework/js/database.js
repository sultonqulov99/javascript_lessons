const usersData = [
	{ 
		userId: 1, 
		username: 'ali', 
		fullName: 'ali zairov', 
		email: 'ali@gmail.com',
		bio: null,
		password: '1234',
		checked: true,
		isActive: true,
		date: '2022-10-02'
	},
	{ 
		userId: 2, 
		username: 'halil', 
		fullName: 'halil nosirov', 
		email: 'halil@gmail.com',
		bio: null,
		password: '1234',
		checked: false,
		isActive: false,
		date: '2022-10-02'
	},
	{ 
		userId: 3, 
		username: 'hafsa', 
		fullName: 'hafsa muhiddinova', 
		email: 'hafsa@gmail.com',
		bio: null,
		password: '1234',
		checked: true,
		isActive: false,
		date: '2022-10-02'
	}
]